window.__BOOK_MANIFEST__ = [
  {
    "id": "001",
    "title": "Title Page",
    "file": "001-title.html"
  },
  {
    "id": "002",
    "title": "Preface (Placeholder)",
    "file": "002-preface.html"
  },
  {
    "id": "010",
    "title": "Population Numbers 1947–2025",
    "file": "010-population.html"
  },
  {
    "id": "020",
    "title": "Inflation Trend 1947–2025 (Trend-Filled)",
    "file": "020-inflation.html"
  },
  {
    "id": "030",
    "title": "Cumulative Price Index 1947–2025",
    "file": "030-cumulative.html"
  },
  {
    "id": "040",
    "title": "Cumulative Price Index — Legend & Assumptions",
    "file": "040-cumulative-legend.html"
  }
];
function buildTOC(){const toc=document.querySelector('#toc');if(!toc)return;toc.innerHTML='';window.__BOOK_MANIFEST__.forEach(p=>{const a=document.createElement('a');a.className='card';a.href='pages/'+p.file;a.innerHTML=`<h3>${p.id} — ${p.title}</h3><p>Open page</p>`;toc.appendChild(a);});}
function injectNav(currentFile){const nav=document.querySelector('#nav');if(!nav)return;const list=window.__BOOK_MANIFEST__;const idx=list.findIndex(p=>p.file===currentFile);const prev=list[idx-1];const next=list[idx+1];let html=`<a class='ghost' href='../index.html'>← Back to Contents</a>`;if(prev)html+=` <a class='secondary' href='${prev.file}'>← Prev</a>`;if(next)html+=` <a href='${next.file}'>Next →</a>`;nav.innerHTML=html;}
document.addEventListener('DOMContentLoaded',()=>{buildTOC();});